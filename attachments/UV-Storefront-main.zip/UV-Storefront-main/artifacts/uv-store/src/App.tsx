import { useEffect, useMemo, useState } from 'react';
import type { ChangeEvent, FormEvent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import { ArrowDownRight, ArrowLeft, ArrowRight, Check, ChevronDown, CircleAlert, CreditCard, Eye, EyeOff, LoaderCircle, LockKeyhole, Menu, Minus, Plus, Search, ShieldCheck, ShoppingBag, SlidersHorizontal, Trash2, Truck, X } from 'lucide-react';
import {
  getGetAdminDashboardQueryKey, getGetProductQueryKey, getListAccountOrdersQueryKey,
  getListAdminOrdersQueryKey, getListAdminProductsQueryKey, getListCollectionsQueryKey,
  getListInventoryQueryKey, getListProductsQueryKey, useCreateCheckoutOrder, useCreateProduct,
  useDeleteProduct, useGetAdminDashboard, useGetProduct, useListAccountOrders,
  useListAdminOrders, useListAdminProducts, useListCollections, useListInventory,
  useListProducts, useUpdateInventory, useUpdateOrderStatus, useUpdateProduct,
  useVerifyCheckoutPayment,
} from '@workspace/api-client-react';
import type { Collection, InventoryItem, Order, Product, ProductInput } from '@workspace/api-client-react';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 25_000, retry: 1 } } });
const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
const authUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const authKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const storageBucket = import.meta.env.VITE_SUPABASE_STORAGE_BUCKET as string | undefined;
const cartStorage = 'uv-store-cart-v1';
type CartItem = { product: Product; quantity: number; size: string; color: string };
type AuthState = { access_token: string; refresh_token?: string; expires_at?: number; user?: { id?: string; email?: string } };
const tokenKey = 'uv-store-session';

function getSession(): AuthState | null {
  try { return JSON.parse(localStorage.getItem(tokenKey) || 'null') as AuthState | null; } catch { return null; }
}
function authRequest(accessToken?: string) {
  const headers: Record<string, string> = {};
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  return { headers };
}
function useCart() {
  const [items, setItems] = useState<CartItem[]>(() => {
    try { return JSON.parse(localStorage.getItem(cartStorage) || '[]') as CartItem[]; } catch { return []; }
  });
  useEffect(() => { localStorage.setItem(cartStorage, JSON.stringify(items)); }, [items]);
  const add = (product: Product, size: string, color: string) => setItems(current => {
    const found = current.find(line => line.product.id === product.id && line.size === size && line.color === color);
    return found ? current.map(line => line === found ? { ...line, quantity: Math.min(10, line.quantity + 1) } : line) : [...current, { product, size, color, quantity: 1 }];
  });
  const quantity = (id: string, size: string, color: string, amount: number) => setItems(lines => lines.map(line => line.product.id === id && line.size === size && line.color === color ? { ...line, quantity: Math.max(1, Math.min(10, amount)) } : line));
  const remove = (id: string, size: string, color: string) => setItems(lines => lines.filter(line => !(line.product.id === id && line.size === size && line.color === color)));
  const changeVariant = (id: string, oldSize: string, oldColor: string, size: string, color: string) => setItems(lines => {
    const moving = lines.find(line => line.product.id === id && line.size === oldSize && line.color === oldColor);
    if (!moving) return lines;
    const existing = lines.find(line => line.product.id === id && line.size === size && line.color === color);
    if (existing && existing !== moving) {
      return lines.filter(line => line !== moving).map(line => line === existing ? { ...line, quantity: Math.min(10, line.quantity + moving.quantity) } : line);
    }
    return lines.map(line => line === moving ? { ...line, size, color } : line);
  });
  return { items, add, quantity, remove, changeVariant, count: items.reduce((n, i) => n + i.quantity, 0), total: items.reduce((n, i) => n + i.product.price * i.quantity, 0), clear: () => setItems([]) };
}
type Cart = ReturnType<typeof useCart>;

function Title({ title, description }: { title: string; description: string }) {
  useEffect(() => {
    const pageTitle = `${title} — UV`;
    document.title = pageTitle;
    const setMeta = (selector: string, attribute: string, value: string) => {
      let node = document.querySelector<HTMLMetaElement>(selector);
      if (!node) {
        node = document.createElement('meta');
        node.setAttribute(attribute === 'property' ? 'property' : 'name', selector.includes('og:') ? selector.split('"')[1] : selector.split('"')[1]);
        document.head.appendChild(node);
      }
      node.setAttribute('content', value);
    };
    setMeta('meta[name="description"]', 'name', description);
    setMeta('meta[property="og:title"]', 'property', pageTitle);
    setMeta('meta[property="og:description"]', 'property', description);
    setMeta('meta[name="twitter:title"]', 'name', pageTitle);
    setMeta('meta[name="twitter:description"]', 'name', description);
    const canonicalPath = `${window.location.origin}${window.location.pathname}`;
    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalPath;
  }, [title, description]);
  return null;
}
function imageSrc(url?: string | null) {
  if (!url) return undefined;
  if (/^https?:\/\//i.test(url)) return url;
  return `${import.meta.env.BASE_URL.replace(/\/$/, '')}/${url.replace(/^\//, '')}`;
}
function Image({ product, className = '' }: { product?: Product; className?: string }) {
  const src = imageSrc(product?.images?.[0]?.url);
  return src ? <img className={className} src={src} alt={product?.images?.[0]?.alt || product?.name || 'UV menswear'} loading="lazy" /> :
    <div className={`image-placeholder ${className}`} aria-label="Product image not yet available"><span>UV</span></div>;
}
function Header({ cartCount }: { cartCount: number }) {
  const [menu, setMenu] = useState(false);
  const collections = useListCollections({ query: { queryKey: getListCollectionsQueryKey() } });
  return <>
    <div className="announcement">Complimentary shipping on orders over ₹2,500 <span>—</span> Made for the long way around.</div>
    <header className="site-header">
      <button className="icon-button mobile-menu" aria-label={menu ? 'Close menu' : 'Open menu'} aria-expanded={menu} data-testid="button-open-menu" onClick={() => setMenu(!menu)}><Menu size={19} /></button>
      <Link href="/" className="wordmark" data-testid="link-home">UV<span>®</span></Link>
      <nav className={`main-nav ${menu ? 'nav-open' : ''}`} aria-label="Main navigation">
        <Link href="/shop" onClick={() => setMenu(false)}>Shop all</Link>
        <Link href="/shop" onClick={() => setMenu(false)}>Collections</Link>
        {(collections.data ?? []).slice(0, 2).map(collection => <Link key={collection.slug} href={`/shop?category=${encodeURIComponent(collection.slug)}`} onClick={() => setMenu(false)}>{collection.name}</Link>)}
        <Link href="/about" onClick={() => setMenu(false)}>About</Link>
      </nav>
      <div className="header-actions">
        <Link href="/shop" className="header-search" aria-label="Search the collection"><Search size={17} /><span>Search</span></Link>
        <Link href="/account" className="header-account">Account</Link>
        <Link href="/cart" className="bag-link" data-testid="link-cart"><ShoppingBag size={18} strokeWidth={1.6} /><span>Bag ({cartCount})</span></Link>
      </div>
    </header>
  </>;
}
function Footer() {
  return <footer className="site-footer"><div className="footer-top"><div><Link href="/" className="wordmark footer-mark">UV<span>®</span></Link><p>Considered clothing.<br />Made to be worn, often.</p></div><div className="footer-links"><div><span>Explore</span><Link href="/shop">Shop all</Link><Link href="/about">About UV</Link><Link href="/account">Your account</Link></div><div><span>Need a hand?</span><Link href="/contact">Contact</Link><Link href="/shipping">Shipping</Link><Link href="/returns">Returns</Link></div><div><span>Information</span><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link><a href="https://instagram.com" target="_blank" rel="noreferrer">Instagram ↗</a></div></div></div><div className="footer-bottom"><span>© UV {new Date().getFullYear()}</span><span>Designed for everyday, not just every day.</span><Link href="/admin">Store access</Link></div></footer>;
}
function Shell({ cart, children }: { cart: Cart; children: ReactNode }) {
  return <><Header cartCount={cart.count} />{children}<Footer /></>;
}
function Status({ error, retry }: { error: unknown; retry?: () => void }) {
  return <div className="state-message"><CircleAlert size={22} /><h2>We couldn't load this just now.</h2><p>{error instanceof Error ? error.message : 'Please try again in a moment.'}</p>{retry && <button className="button button-dark" onClick={retry}>Try again</button>}</div>;
}
function LoadingGrid() { return <div className="product-grid">{[0,1,2,3].map(i => <div className="skeleton-card" key={i}><div className="skeleton-image" /><div className="skeleton-line" /><div className="skeleton-line short" /></div>)}</div>; }
function ProductCard({ product }: { product: Product }) {
  return <Link href={`/products/${product.slug}`} className="product-card" data-testid={`card-product-${product.id}`}>
    <div className="product-photo"><Image product={product} className="product-image" />{(product.newArrival || product.featured) && <span className="product-flag">{product.newArrival ? 'NEW ARRIVAL' : 'UV SELECT'}</span>}<span className="quick-view">View piece <ArrowRight size={14} /></span></div>
    <div className="product-meta"><div><h3>{product.name}</h3><p>{product.category}</p></div><strong>{money(product.price)}</strong></div>
  </Link>;
}
function HomePage() {
  const products = useListProducts({ page: 1, pageSize: 4, sort: 'featured' }, { query: { queryKey: getListProductsQueryKey({ page: 1, pageSize: 4, sort: 'featured' }) } });
  const collections = useListCollections({ query: { queryKey: getListCollectionsQueryKey() } });
  return <><Title title="UV — Considered menswear" description="A modern uniform for wherever the day takes you. Explore considered menswear by UV." />
    <main>
      <section className="hero">
        <img className="hero-image" src="/uv-editorial-hero.png" alt="UV editorial campaign in a sculptural charcoal overshirt" />
        <div className="hero-shade" />
        <div className="hero-copy"><span className="eyebrow light">THE EVERYDAY, RECONSIDERED — VOL. 01</span><h1>Quietly<br /><em>distinct.</em></h1><p>Modern menswear for the hours that matter, and all the ones in between.</p><Link href="/shop" className="button button-light">Explore the collection <ArrowRight size={16} /></Link></div>
        <div className="hero-index"><span>01 / 03</span><span>THE FORM STUDY</span></div>
      </section>
      <section className="editorial-intro section-wrap"><span className="eyebrow">A BETTER KIND OF BASIC</span><p>Less, but with <span>more to say.</span></p><div className="intro-foot"><span>Designed in restraint.<br />Made for the real world.</span><Link href="/shop" className="text-link">Discover UV <ArrowDownRight size={15} /></Link></div></section>
      <section className="section-wrap collection-band"><div className="section-heading"><div><span className="eyebrow">THE UV WARDROBE</span><h2>Find your <em>form.</em></h2></div><Link href="/shop" className="text-link">Shop all pieces <ArrowRight size={15} /></Link></div>
        {collections.isLoading ? <div className="collection-loading">Finding your way around…</div> : collections.isError ? <Status error={collections.error} retry={() => collections.refetch()} /> :
          <div className="collection-row">{(collections.data ?? []).slice(0, 3).map((c: Collection, i: number) => <Link className={`collection-tile tone-${i}`} key={c.slug} href={`/shop?category=${encodeURIComponent(c.name)}`}><div className="collection-art">{c.image ? <img src={c.image} alt={c.name} /> : <span>0{i + 1}</span>}</div><div><h3>{c.name}</h3><span>{c.productCount} pieces <ArrowRight size={14} /></span></div></Link>)}</div>}
      </section>
      <section className="section-wrap new-arrivals"><div className="section-heading"><div><span className="eyebrow">FIRST LOOK</span><h2>In good <em>company.</em></h2></div><Link href="/shop" className="text-link">View the collection <ArrowRight size={15} /></Link></div>
        {products.isLoading ? <LoadingGrid /> : products.isError ? <Status error={products.error} retry={() => products.refetch()} /> : products.data?.items.length ? <div className="product-grid">{products.data.items.map(p => <ProductCard product={p} key={p.id} />)}</div> : <EmptyState title="The next collection is on its way." copy="There's nothing on the rail just yet. Check back soon." action={<Link href="/shop" className="text-link">Browse the shop <ArrowRight size={15} /></Link>} />}
      </section>
      <section className="manifesto"><span className="eyebrow light">A NOTE ON CLOTHES</span><h2>Wear it in.<br /><em>Wear it out.</em></h2><p>Pieces with room to become yours. No noise, no occasion required.</p><Link href="/shop" className="button button-light">Meet the collection <ArrowRight size={16} /></Link></section>
      <section className="service-strip"><div><Truck size={19} /><span><strong>Considered delivery</strong>Free shipping over ₹5,000</span></div><div><ShieldCheck size={19} /><span><strong>Made to last</strong>Quality, in every detail</span></div><div><CreditCard size={19} /><span><strong>Secure checkout</strong>Protected at every step</span></div></section>
    </main></>;
}
function EmptyState({ title, copy, action }: { title: string; copy: string; action?: ReactNode }) { return <div className="empty-state"><div className="empty-mark">UV</div><h2>{title}</h2><p>{copy}</p>{action}</div>; }
function ShopPage() {
  const [search, setSearch] = useState(() => new URLSearchParams(window.location.search).get('search') || '');
  const [category, setCategory] = useState(() => new URLSearchParams(window.location.search).get('category') || '');
  const [size, setSize] = useState('');
  const [color, setColor] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sort, setSort] = useState('featured');
  const [mobileFilters, setMobileFilters] = useState(false);
  const [page, setPage] = useState(1);
  useEffect(() => { const t = setTimeout(() => setPage(1), 250); return () => clearTimeout(t); }, [search, category, size, color, minPrice, maxPrice, sort]);
  const filters = useMemo(() => ({
    search: search || undefined,
    category: category || undefined,
    size: size || undefined,
    color: color || undefined,
    minPrice: minPrice === '' ? undefined : Number(minPrice),
    maxPrice: maxPrice === '' ? undefined : Number(maxPrice),
    sort: sort as 'featured' | 'newest' | 'price-asc' | 'price-desc',
    page,
    pageSize: 12,
  }), [search, category, size, color, minPrice, maxPrice, sort, page]);
  const query = useListProducts(filters, { query: { queryKey: getListProductsQueryKey(filters), placeholderData: previous => previous } });
  const collections = useListCollections({ query: { queryKey: getListCollectionsQueryKey() } });
  const facets = useListProducts({ page: 1, pageSize: 48 }, { query: { queryKey: getListProductsQueryKey({ page: 1, pageSize: 48 }) } });
  const availableSizes = [...new Set((facets.data?.items ?? []).flatMap(product => product.sizes))].sort();
  const availableColors = [...new Set((facets.data?.items ?? []).flatMap(product => product.colors))].sort();
  const clearFilters = () => { setCategory(''); setSearch(''); setSize(''); setColor(''); setMinPrice(''); setMaxPrice(''); };
  const result = query.data?.items || [];
  return <><Title title="Shop menswear — UV" description="Shop UV's collection of modern menswear. Considered essentials, outerwear and everyday layers." /><main className="shop-page">
    <div className="page-title"><span className="eyebrow">THE UV WARDROBE</span><h1>Shop <em>all.</em></h1><p>Considered pieces. Everyday possibility.</p></div>
    <div className="catalog-toolbar"><span>{query.data?.total ?? '—'} pieces</span><button className="filter-toggle" onClick={() => setMobileFilters(!mobileFilters)}><SlidersHorizontal size={15} /> Filters</button><label className="search-control"><Search size={16} /><input aria-label="Search the collection" placeholder="Search the collection" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-product-search" />{search && <button aria-label="Clear search" onClick={() => setSearch('')}><X size={14} /></button>}</label><label className="sort-control">Sort <select aria-label="Sort products" value={sort} onChange={e => setSort(e.target.value)}><option value="featured">Featured</option><option value="newest">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option></select><ChevronDown size={13} /></label></div>
    <div className="catalog-layout"><aside className={`filter-panel ${mobileFilters ? 'filters-open' : ''}`}><div className="filter-head">Refine <button onClick={clearFilters} className="clear-filter">Clear all</button></div><div className="filter-group"><h3>Category</h3><button className={!category ? 'filter-option selected' : 'filter-option'} onClick={() => setCategory('')}>All pieces</button>{(collections.data ?? []).map(c => <button key={c.slug} className={category === c.slug ? 'filter-option selected' : 'filter-option'} onClick={() => setCategory(category === c.slug ? '' : c.slug)}>{c.name}<span>{c.productCount}</span></button>)}</div>
      <div className="filter-group"><h3>Size</h3><select aria-label="Filter by size" className="filter-input" value={size} onChange={e => setSize(e.target.value)}><option value="">All sizes</option>{availableSizes.map(value => <option key={value} value={value}>{value}</option>)}</select></div>
      <div className="filter-group"><h3>Colour</h3><select aria-label="Filter by colour" className="filter-input" value={color} onChange={e => setColor(e.target.value)}><option value="">All colours</option>{availableColors.map(value => <option key={value} value={value}>{value}</option>)}</select></div>
      <div className="filter-group"><h3>Price range</h3><div className="price-filter"><label><span>Min ₹</span><input className="filter-input" type="number" min="0" value={minPrice} onChange={e => setMinPrice(e.target.value)} /></label><label><span>Max ₹</span><input className="filter-input" type="number" min="0" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} /></label></div></div>
      <div className="filter-note">A wardrobe is built one good decision at a time.</div></aside>
      <div className="catalog-results">{query.isLoading ? <LoadingGrid /> : query.isError ? <Status error={query.error} retry={() => query.refetch()} /> : result.length ? <><div className="product-grid">{result.map(p => <ProductCard product={p} key={p.id} />)}</div>{query.data && query.data.total > 12 && <div className="pagination"><span>Showing {(page - 1) * 12 + 1}–{Math.min(page * 12, query.data.total)} of {query.data.total}</span><div><button disabled={page <= 1} onClick={() => setPage(page - 1)} aria-label="Previous page"><ArrowLeft size={16} /></button><span>{page}</span><button disabled={page * 12 >= query.data.total} onClick={() => setPage(page + 1)} aria-label="Next page"><ArrowRight size={16} /></button></div></div>}</> : <EmptyState title="No pieces found." copy="Try another search or clear your filters." action={<button className="text-link" onClick={() => { setCategory(''); setSearch(''); }}>Clear filters <X size={14} /></button>} />}</div>
    </div></main></>;
}
function ProductPageView({ cart }: { cart: Cart }) {
  const { slug = '' } = useParams<{ slug: string }>();
  const product = useGetProduct(slug, { query: { queryKey: getGetProductQueryKey(slug) } });
  const [size, setSize] = useState('');
  const [color, setColor] = useState('');
  const [added, setAdded] = useState(false);
  useEffect(() => { if (product.data) { setSize(product.data.sizes[0] || ''); setColor(product.data.colors[0] || ''); } }, [product.data?.id]);
  if (product.isLoading) return <main className="product-detail"><LoadingGrid /></main>;
  if (product.isError || !product.data) return <main className="product-detail"><Status error={product.error} retry={() => product.refetch()} /></main>;
  const p = product.data;
  return <><Title title={`${p.name} — UV`} description={p.description || `${p.name} from UV's considered menswear collection.`} /><main className="product-detail">
    <div className="breadcrumbs"><Link href="/shop">Shop</Link><span>/</span><span>{p.category}</span><span>/</span><span>{p.name}</span></div>
    <div className="detail-grid"><div className="detail-gallery">{p.images.length ? p.images.map((im, i) => <img key={`${im.url}-${i}`} src={imageSrc(im.url)} alt={im.alt || p.name} className="detail-image" loading={i === 0 ? 'eager' : 'lazy'} />) : <Image product={p} className="detail-image" />}</div>
      <aside className="detail-info"><span className="eyebrow">{p.category} / UV STUDIO</span><h1>{p.name}</h1><div className="detail-price">{money(p.price)}{p.compareAtPrice && p.compareAtPrice > p.price && <del>{money(p.compareAtPrice)}</del>}</div><p className="detail-description">{p.description}</p>
        <div className="choice-group"><div className="choice-label">Colour <span>{color}</span></div><div className="color-options">{p.colors.map(c => <button className={`color-chip ${color === c ? 'chosen' : ''}`} key={c} onClick={() => setColor(c)} aria-label={`Choose ${c}`} title={c}><span style={{ background: c.toLowerCase().includes('black') ? '#272522' : c.toLowerCase().includes('navy') ? '#303c44' : c.toLowerCase().includes('olive') ? '#727467' : c.toLowerCase().includes('white') ? '#f0eee8' : '#b7a998' }} /></button>)}</div></div>
        <div className="choice-group"><div className="choice-label">Size <span><button className="text-link tiny" onClick={() => window.alert('For the best fit, choose your usual size. For a relaxed fit, size up.')} >Size guide</button></span></div><div className="size-options">{p.sizes.map(s => <button key={s} onClick={() => setSize(s)} className={size === s ? 'size-chip chosen' : 'size-chip'}>{s}</button>)}</div></div>
        <div className="product-actions"><button className="button button-dark add-button" disabled={!p.stock || !size || !color} onClick={() => { cart.add(p, size, color); setAdded(true); setTimeout(() => setAdded(false), 2200); }} data-testid="button-add-to-bag">{added ? <><Check size={16} /> Added to bag</> : <><span>Add to bag</span><span>{money(p.price)}</span></>}</button><button className="button button-outline" disabled={!p.stock || !size || !color} onClick={() => { cart.add(p, size, color); window.location.assign(`${import.meta.env.BASE_URL.replace(/\/$/, '')}/checkout`); }}>Buy now</button></div>
        {!p.stock && <p className="stock-message">Currently out of stock</p>}{p.stock > 0 && p.stock <= 5 && <p className="stock-message">Only {p.stock} left in this colour</p>}
        <div className="product-perks"><p><Truck size={17} /> Complimentary shipping over ₹5,000</p><p><ShieldCheck size={17} /> Easy 7-day returns</p><p><LockKeyhole size={17} /> Secure, encrypted checkout</p></div>
        <details className="detail-disclosure"><summary>Details & care <Plus size={15} /></summary><p>Designed with a focus on fabric, fit and the details that make a piece feel considered. Follow the care label to keep yours in rotation.</p></details>
      </aside></div></main></>;
}
function CartPage({ cart }: { cart: Cart }) {
  const shipping = cart.total >= 2500 ? 0 : 99;
  return <><Title title="Your bag — UV" description="Review your UV pieces before checkout." /><main className="cart-page"><div className="page-title left"><span className="eyebrow">YOUR SELECTION</span><h1>Your <em>bag.</em></h1><p>{cart.count} {cart.count === 1 ? 'piece' : 'pieces'} reserved for you.</p></div>
    {!cart.items.length ? <EmptyState title="A little room for something good." copy="Your bag is waiting for the right piece." action={<Link href="/shop" className="button button-dark">Explore the collection <ArrowRight size={16} /></Link>} /> :
      <div className="cart-layout"><div className="cart-lines">{cart.items.map((line, i) => <article className="cart-line" key={`${line.product.id}-${line.size}-${line.color}`}><Link href={`/products/${line.product.slug}`} className="cart-thumb"><Image product={line.product} /></Link><div className="cart-line-info"><Link href={`/products/${line.product.slug}`}><h2>{line.product.name}</h2></Link><div className="cart-variants"><label>Colour<select className="cart-variant" value={line.color} onChange={e => cart.changeVariant(line.product.id, line.size, line.color, line.size, e.target.value)}>{line.product.colors.map(value => <option key={value}>{value}</option>)}</select></label><label>Size<select className="cart-variant" value={line.size} onChange={e => cart.changeVariant(line.product.id, line.size, line.color, e.target.value, line.color)}>{line.product.sizes.map(value => <option key={value}>{value}</option>)}</select></label></div><div className="quantity-control"><button onClick={() => cart.quantity(line.product.id, line.size, line.color, line.quantity - 1)} aria-label="Decrease quantity"><Minus size={13} /></button><span>{line.quantity}</span><button onClick={() => cart.quantity(line.product.id, line.size, line.color, line.quantity + 1)} aria-label="Increase quantity"><Plus size={13} /></button></div></div><strong>{money(line.product.price * line.quantity)}</strong><button className="remove-button" aria-label="Remove item" onClick={() => cart.remove(line.product.id, line.size, line.color)}><Trash2 size={16} /></button></article>)}</div>
        <aside className="summary-card"><span className="eyebrow">ORDER SUMMARY</span><div><span>Subtotal</span><strong>{money(cart.total)}</strong></div><div><span>Shipping</span><span>{shipping === 0 ? 'Complimentary' : money(shipping)}</span></div><div className="summary-total"><span>Total</span><strong>{money(cart.total + shipping)}</strong></div><p>Taxes included where applicable.</p><Link href="/checkout" className="button button-dark full">Continue to checkout <ArrowRight size={16} /></Link><Link href="/shop" className="text-link continue-shopping">Continue shopping</Link></aside>
      </div>}</main></>;
}
function CheckoutPage({ cart }: { cart: Cart }) {
  const shipping = cart.total >= 2500 ? 0 : 99;
  const [message, setMessage] = useState('');
  const [busyPayment, setBusyPayment] = useState(false);
  const queryClient = useQueryClient();
  const createOrder = useCreateCheckoutOrder({ request: authRequest(getSession()?.access_token) });
  const verifyPayment = useVerifyCheckoutPayment({ request: authRequest(getSession()?.access_token) });
  useEffect(() => {
    if (document.querySelector('script[data-razorpay-sdk]')) return;
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.dataset.razorpaySdk = 'true';
    document.head.appendChild(script);
  }, []);
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', address: '', city: '', state: '', pincode: '' });
  const update = (e: ChangeEvent<HTMLInputElement>) => setForm({ ...form, [e.target.name]: e.target.value });
  const pay = async (e: FormEvent) => {
    e.preventDefault(); setMessage('');
    if (!cart.items.length) { setMessage('Your bag is empty. Add a piece before checkout.'); return; }
    setBusyPayment(true);
    try {
      const session = await createOrder.mutateAsync({ data: { items: cart.items.map(i => ({ productId: i.product.id, quantity: i.quantity, size: i.size, color: i.color })), shippingAddress: form } });
      const RazorpayConstructor = (window as Window & { Razorpay?: new (options: Record<string, unknown>) => { open: () => void } }).Razorpay;
      if (!session.keyId || !session.razorpayOrderId || !RazorpayConstructor) {
        setMessage('Payments are not available yet. Razorpay checkout is not configured for this store. Your bag is unchanged; please try again later.');
        setBusyPayment(false); return;
      }
      const checkout = new RazorpayConstructor({
        key: session.keyId, amount: session.amount, currency: session.currency, order_id: session.razorpayOrderId,
        name: 'UV', description: `Order ${session.orderNumber}`, prefill: { name: form.fullName, email: form.email, contact: form.phone },
        theme: { color: '#302d29' },
        handler: async (response: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
          try {
            const confirmation = await verifyPayment.mutateAsync({ orderId: session.orderId, data: { razorpayOrderId: response.razorpay_order_id, razorpayPaymentId: response.razorpay_payment_id, razorpaySignature: response.razorpay_signature } });
            if (confirmation.paymentStatus !== 'paid') throw new Error('Payment could not be confirmed.');
            sessionStorage.setItem('uv-confirmation', JSON.stringify(confirmation));
            cart.clear(); await queryClient.invalidateQueries({ queryKey: getListAccountOrdersQueryKey() });
            window.location.assign('/orders/confirmed');
          } catch (error) { setMessage(error instanceof Error ? error.message : 'Payment verification failed. Contact support before trying again.'); setBusyPayment(false); }
        },
        modal: { ondismiss: () => setBusyPayment(false) },
      });
      checkout.open();
    } catch (error) { setMessage(error instanceof Error ? error.message : 'We could not start checkout. Please review your details and try again.'); setBusyPayment(false); }
  };
  return <><Title title="Checkout — UV" description="Securely complete your UV order." /><main className="checkout-page"><div className="checkout-heading"><Link href="/cart" className="text-link"><ArrowLeft size={15} /> Return to bag</Link><h1>Almost <em>yours.</em></h1><p>Guest checkout · No account needed</p></div>
    {!cart.items.length ? <EmptyState title="Your bag is empty." copy="Add something considered to your bag to continue." action={<Link className="button button-dark" href="/shop">Shop the collection <ArrowRight size={16} /></Link>} /> :
    <div className="checkout-layout"><form className="checkout-form" onSubmit={pay}><section><span className="eyebrow">01 / CONTACT</span><h2>Where can we reach you?</h2><div className="form-grid"><label className="field full-field">Email address<input required name="email" type="email" value={form.email} onChange={update} autoComplete="email" /></label><label className="field full-field">Full name<input required name="fullName" value={form.fullName} onChange={update} autoComplete="name" /></label><label className="field full-field">Phone number<input required name="phone" type="tel" value={form.phone} onChange={update} autoComplete="tel" /></label></div></section><section><span className="eyebrow">02 / DELIVERY</span><h2>Where should it go?</h2><div className="form-grid"><label className="field full-field">Address<input required name="address" value={form.address} onChange={update} autoComplete="street-address" /></label><label className="field">City<input required name="city" value={form.city} onChange={update} autoComplete="address-level2" /></label><label className="field">State<input required name="state" value={form.state} onChange={update} autoComplete="address-level1" /></label><label className="field">PIN code<input required name="pincode" value={form.pincode} onChange={update} autoComplete="postal-code" /></label></div></section>
      {message && <div className="inline-error" role="alert"><CircleAlert size={17} />{message}</div>}<button className="button button-dark full pay-button" disabled={busyPayment || createOrder.isPending || verifyPayment.isPending}>{busyPayment || createOrder.isPending || verifyPayment.isPending ? <><LoaderCircle className="spin" size={16} /> Preparing secure checkout</> : <>Continue to secure payment <ArrowRight size={16} /></>}</button><p className="secure-note"><LockKeyhole size={14} /> Your details are encrypted and secure.</p></form>
      <aside className="checkout-summary"><span className="eyebrow">IN YOUR BAG</span>{cart.items.map(line => <div className="checkout-item" key={`${line.product.id}${line.size}`}><div className="checkout-thumb"><Image product={line.product} /><span>{line.quantity}</span></div><div><strong>{line.product.name}</strong><p>{line.color} / {line.size}</p></div><b>{money(line.product.price * line.quantity)}</b></div>)}<div><span>Subtotal</span><strong>{money(cart.total)}</strong></div><div><span>Shipping</span><span>{shipping === 0 ? 'Complimentary' : money(shipping)}</span></div><div className="summary-total"><span>Total</span><strong>{money(cart.total + shipping)}</strong></div><p>Payment is completed securely via Razorpay. We never store card details.</p></aside></div>}</main></>;
}
function ConfirmationPage() {
  let confirmation: { order?: Order; paymentStatus?: string } | null = null;
  try { confirmation = JSON.parse(sessionStorage.getItem('uv-confirmation') || 'null'); } catch { confirmation = null; }
  return <><Title title="Order confirmed — UV" description="Your UV order is confirmed." /><main className="confirmation-page">{confirmation?.paymentStatus === 'paid' && confirmation.order ? <div className="confirmation-card reveal"><div className="confirmation-seal"><Check size={27} /></div><span className="eyebrow">IT'S OFFICIAL</span><h1>Good things<br /><em>are coming.</em></h1><p>Thank you, {confirmation.order.customerName}. Your order is confirmed and on its way to becoming a favourite.</p><div className="confirmation-order"><span>ORDER NUMBER</span><strong>{confirmation.order.orderNumber}</strong><span>{confirmation.order.items.length} pieces · {money(confirmation.order.total)}</span></div><Link href="/shop" className="button button-dark">Back to the collection <ArrowRight size={16} /></Link></div> : <EmptyState title="No confirmed order found." copy="We only show this page after a successful payment confirmation." action={<Link href="/shop" className="button button-dark">Return to UV <ArrowRight size={16} /></Link>} />}</main></>;
}
async function supabaseSignIn(email: string, password: string): Promise<AuthState> {
  if (!authUrl || !authKey) throw new Error('Sign-in is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to enable Supabase Auth.');
  const response = await fetch(`${authUrl.replace(/\/$/, '')}/auth/v1/token?grant_type=password`, { method: 'POST', headers: { 'Content-Type': 'application/json', apikey: authKey }, body: JSON.stringify({ email, password }) });
  const result = await response.json() as AuthState & { msg?: string; message?: string; error_description?: string };
  if (!response.ok) throw new Error(result.msg || result.message || result.error_description || 'Unable to sign in. Check your details and try again.');
  return result;
}
function AccountPage() {
  const [session, setSession] = useState<AuthState | null>(() => getSession());
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const orders = useListAccountOrders({ query: { queryKey: getListAccountOrdersQueryKey(), enabled: !!session?.access_token }, request: { headers: session ? { Authorization: `Bearer ${session.access_token}` } : {} } });
  const signin = async (e: FormEvent) => { e.preventDefault(); setPending(true); setError(''); try { const result = await supabaseSignIn(email, password); localStorage.setItem(tokenKey, JSON.stringify(result)); setSession(result); } catch (err) { setError(err instanceof Error ? err.message : 'Sign-in failed.'); } finally { setPending(false); } };
  return <><Title title="Your account — UV" description="Sign in to view your UV orders." /><main className="account-page"><div className="page-title"><span className="eyebrow">YOUR UV ACCOUNT</span><h1>{session ? 'Your orders.' : <>Welcome <em>back.</em></>}</h1><p>{session ? 'A little history, all in one place.' : 'Sign in to find your pieces.'}</p></div>
    {session ? <div className="account-orders"><div className="account-bar"><span>Signed in as {session.user?.email || email}</span><button className="text-link" onClick={() => { localStorage.removeItem(tokenKey); setSession(null); }}>Sign out</button></div>{orders.isLoading ? <div className="state-message">Loading your orders…</div> : orders.isError ? <Status error={orders.error} retry={() => orders.refetch()} /> : orders.data?.length ? orders.data.map(order => <OrderCard key={order.id} order={order} />) : <EmptyState title="No orders yet." copy="Your next favourite is waiting in the collection." action={<Link href="/shop" className="text-link">Shop UV <ArrowRight size={15} /></Link>} />}</div> :
      <form className="auth-card" onSubmit={signin}><span className="eyebrow">CUSTOMER SIGN IN</span><label className="field">Email address<input data-testid="input-account-email" type="email" required autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label><label className="field password-field">Password<div><input data-testid="input-account-password" type={showPassword ? 'text' : 'password'} required autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} /><button type="button" aria-label="Show password" onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></label>{error && <div className="inline-error"><CircleAlert size={16} />{error}</div>}{!authUrl || !authKey ? <p className="setup-note">Supabase Auth setup needed: configure <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code>. UV does not create local passwords.</p> : null}<button className="button button-dark full" disabled={pending || !authUrl || !authKey}>{pending ? 'Signing in…' : 'Sign in securely'}</button><p className="auth-foot">New to UV? Your account is created when you place an order.</p></form>}
  </main></>;
}
function OrderCard({ order }: { order: Order }) { return <article className="order-card"><div className="order-card-top"><div><span className="eyebrow">ORDER {order.orderNumber}</span><p>{new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p></div><div><span className={`status-pill ${order.status}`}>{order.status}</span><strong>{money(order.total)}</strong></div></div><div className="order-items">{order.items.map((i, n) => <div key={`${i.productName}-${n}`}><span>{i.productName} <small>× {i.quantity}</small></span><span>{i.color} / {i.size}</span></div>)}</div></article>; }
function AdminLogin({ onLogin }: { onLogin: (session: AuthState) => void }) {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState(''); const [pending, setPending] = useState(false);
  const submit = async (e: FormEvent) => { e.preventDefault(); setPending(true); setError(''); try { const auth = await supabaseSignIn(email, password); localStorage.setItem(tokenKey, JSON.stringify(auth)); onLogin(auth); } catch (err) { setError(err instanceof Error ? err.message : 'Sign-in failed.'); } finally { setPending(false); } };
  return <div className="admin-login-wrap"><form className="auth-card admin-login" onSubmit={submit}><Link href="/" className="wordmark">UV<span>®</span></Link><span className="eyebrow">OWNER ACCESS</span><h1>Good evening.</h1><p>Sign in to manage the UV store.</p><label className="field">Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} /></label><label className="field">Password<input type="password" required value={password} onChange={e => setPassword(e.target.value)} /></label>{error && <div className="inline-error"><CircleAlert size={16} />{error}</div>}{(!authUrl || !authKey) && <p className="setup-note">Configure Supabase Auth to enable owner sign-in. No local password is stored.</p>}<button className="button button-dark full" disabled={pending || !authUrl || !authKey}>{pending ? 'Signing in…' : 'Sign in'}</button></form></div>;
}
function AdminPage() {
  const [session, setSession] = useState<AuthState | null>(() => getSession());
  const [tab, setTab] = useState<'overview' | 'products' | 'inventory' | 'orders'>('overview');
  const [editing, setEditing] = useState<Product | null | 'new'>(null);
  const [formError, setFormError] = useState('');
  const [saved, setSaved] = useState('');
  const qc = useQueryClient();
  const req = { headers: session ? { Authorization: `Bearer ${session.access_token}` } : {} };
  const dashboard = useGetAdminDashboard({ query: { queryKey: getGetAdminDashboardQueryKey(), enabled: !!session }, request: req });
  const products = useListAdminProducts({ query: { queryKey: getListAdminProductsQueryKey(), enabled: !!session }, request: req });
  const inventory = useListInventory({ query: { queryKey: getListInventoryQueryKey(), enabled: !!session && tab === 'inventory' }, request: req });
  const orders = useListAdminOrders(undefined, { query: { queryKey: getListAdminOrdersQueryKey(), enabled: !!session && tab === 'orders' }, request: req });
  const create = useCreateProduct(); const update = useUpdateProduct(); const remove = useDeleteProduct(); const updateStock = useUpdateInventory(); const updateStatus = useUpdateOrderStatus();
  const refreshProducts = async () => { await Promise.all([qc.invalidateQueries({ queryKey: getListAdminProductsQueryKey() }), qc.invalidateQueries({ queryKey: getGetAdminDashboardQueryKey() }), qc.invalidateQueries({ queryKey: getListProductsQueryKey() }), qc.invalidateQueries({ queryKey: getListCollectionsQueryKey() })]); };
  if (!session) return <><Title title="UV Store Admin" description="Owner sign-in for the UV store dashboard." /><AdminLogin onLogin={setSession} /></>;
  const showResult = (message: string) => { setSaved(message); setTimeout(() => setSaved(''), 3000); };
  const tabs = ['overview', 'products', 'inventory', 'orders'] as const;
  return <><Title title="Store dashboard — UV" description="Manage UV products, inventory and orders." /><div className="admin-shell"><aside className="admin-side"><Link href="/" className="wordmark">UV<span>®</span></Link><span className="eyebrow">STORE DESK</span><nav>{tabs.map(t => <button key={t} className={tab === t ? 'active' : ''} onClick={() => setTab(t)}>{t === 'overview' ? 'Overview' : t === 'products' ? 'Products' : t === 'inventory' ? 'Inventory' : 'Orders'}<ArrowRight size={14} /></button>)}</nav><button className="admin-signout" onClick={() => { localStorage.removeItem(tokenKey); setSession(null); }}>Sign out</button></aside>
    <main className="admin-main"><header className="admin-top"><div><span className="eyebrow">UV / OWNER VIEW</span><h1>{tab === 'overview' ? 'Good work, in progress.' : tab[0].toUpperCase() + tab.slice(1)}</h1></div><Link href="/" className="text-link">View storefront <ArrowRight size={14} /></Link></header>
      {saved && <div className="success-banner"><Check size={16} />{saved}</div>}
      {tab === 'overview' && (dashboard.isLoading ? <AdminLoading /> : dashboard.isError ? <Status error={dashboard.error} retry={() => dashboard.refetch()} /> : <><section className="metric-grid"><Metric label="Total orders" value={String(dashboard.data?.totalOrders ?? 0)} note="All time" /><Metric label="Gross revenue" value={money(dashboard.data?.totalRevenue ?? 0)} note="All time" /><Metric label="Live pieces" value={String(dashboard.data?.productCount ?? 0)} note="Across the collection" /><Metric label="Low stock" value={String(dashboard.data?.lowStockCount ?? 0)} note="Worth a closer look" /></section><section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">RECENT ACTIVITY</span><h2>Orders, lately.</h2></div><button className="text-link" onClick={() => setTab('orders')}>All orders <ArrowRight size={14} /></button></div>{dashboard.data?.recentOrders?.length ? <OrderTable orders={dashboard.data.recentOrders} onStatus={(id, status) => updateStatus.mutate({ orderId: id, data: { status } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminDashboardQueryKey() }); qc.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() }); showResult('Order status updated.'); } })} /> : <EmptyState title="No orders have landed yet." copy="Orders will appear here as soon as the first customer checks out." />}</section></>)}
      {tab === 'products' && <section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">THE CATALOG</span><h2>Every piece.</h2></div><button className="button button-dark compact" onClick={() => { setEditing('new'); setFormError(''); }}>Add a piece <Plus size={15} /></button></div>{products.isLoading ? <AdminLoading /> : products.isError ? <Status error={products.error} retry={() => products.refetch()} /> : products.data?.length ? <div className="admin-product-list">{products.data.map(p => <div className="admin-product-row" key={p.id}><div className="admin-product-thumb"><Image product={p} /></div><div className="admin-product-name"><strong>{p.name}</strong><span>{p.sku} · {p.category}</span></div><span>{money(p.price)}</span><span className={`status-pill ${p.published ? 'paid' : 'pending'}`}>{p.published ? 'Published' : 'Draft'}</span><button className="text-link" onClick={() => { setEditing(p); setFormError(''); }}>Edit</button><button className="admin-delete" aria-label={`Delete ${p.name}`} onClick={() => { if (window.confirm(`Delete ${p.name}? This cannot be undone.`)) remove.mutate({ productId: p.id }, { onSuccess: async () => { await refreshProducts(); showResult('Product deleted.'); }, onError: err => setFormError(err.message) }); }}>Delete</button></div>)}</div> : <EmptyState title="Your catalog is ready for its first piece." copy="Add a product to begin building your collection." action={<button className="button button-dark compact" onClick={() => setEditing('new')}>Add a piece <Plus size={15} /></button>} />}{formError && <div className="inline-error"><CircleAlert size={16} />{formError}</div>}</section>}
      {tab === 'inventory' && <section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">STOCK CONTROL</span><h2>On the shelf.</h2></div><span className="admin-count">{inventory.data?.length ?? 0} SKUs</span></div>{inventory.isLoading ? <AdminLoading /> : inventory.isError ? <Status error={inventory.error} retry={() => inventory.refetch()} /> : inventory.data?.length ? <InventoryTable inventory={inventory.data} onSave={(item, stock) => updateStock.mutate({ productId: item.productId, data: { stock } }, { onSuccess: async () => { await Promise.all([qc.invalidateQueries({ queryKey: getListInventoryQueryKey() }), qc.invalidateQueries({ queryKey: getGetAdminDashboardQueryKey() }), qc.invalidateQueries({ queryKey: getListAdminProductsQueryKey() })]); showResult(`${item.productName} stock updated.`); }, onError: err => setFormError(err.message) })} /> : <EmptyState title="No inventory to show." copy="Product stock levels appear here once your catalog is populated." />}{formError && <div className="inline-error">{formError}</div>}</section>}
      {tab === 'orders' && <section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">FULFILMENT</span><h2>Orders.</h2></div><span className="admin-count">{orders.data?.length ?? 0} ORDERS</span></div>{orders.isLoading ? <AdminLoading /> : orders.isError ? <Status error={orders.error} retry={() => orders.refetch()} /> : orders.data?.length ? <OrderTable orders={orders.data} onStatus={(id, status) => updateStatus.mutate({ orderId: id, data: { status } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() }); qc.invalidateQueries({ queryKey: getGetAdminDashboardQueryKey() }); showResult('Order status updated.'); }, onError: err => setFormError(err.message) })} /> : <EmptyState title="Nothing to pack just yet." copy="New orders will arrive here." />}{formError && <div className="inline-error">{formError}</div>}</section>}
    </main></div>{editing && <ProductEditor product={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSave={async payload => { try { setFormError(''); if (editing === 'new') await create.mutateAsync({ data: payload }); else await update.mutateAsync({ productId: editing.id, data: payload }); await refreshProducts(); setEditing(null); showResult(editing === 'new' ? 'Product created.' : 'Product updated.'); } catch (err) { setFormError(err instanceof Error ? err.message : 'Could not save product.'); } }} error={formError} pending={create.isPending || update.isPending} />}</>;
}
function Metric({ label, value, note }: { label: string; value: string; note: string }) { return <article className="metric-card"><span>{label}</span><strong>{value}</strong><small>{note}</small></article>; }
function AdminLoading() { return <div className="admin-skeleton"><div /><div /><div /></div>; }
function OrderTable({ orders, onStatus }: { orders: Order[]; onStatus: (id: string, status: 'processing' | 'shipped' | 'delivered' | 'cancelled') => void }) {
  return <div className="table-scroll"><table className="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Payment</th><th>Fulfilment</th><th>Update</th></tr></thead><tbody>{orders.map(o => <tr key={o.id}><td><strong>{o.orderNumber}</strong><small>{o.items.length} pieces</small></td><td>{o.customerName}<small>{o.customerEmail}</small></td><td>{new Date(o.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</td><td>{money(o.total)}</td><td><span className={`status-pill ${o.paymentStatus}`}>{o.paymentStatus}</span></td><td><span className={`status-pill ${o.status}`}>{o.status}</span></td><td><select aria-label={`Update order ${o.orderNumber}`} value="" onChange={e => { if (e.target.value) onStatus(o.id, e.target.value as 'processing' | 'shipped' | 'delivered' | 'cancelled'); }}><option value="">Change…</option>{['processing','shipped','delivered','cancelled'].map(s => <option value={s} key={s}>{s}</option>)}</select></td></tr>)}</tbody></table></div>;
}
function InventoryTable({ inventory, onSave }: { inventory: InventoryItem[]; onSave: (item: InventoryItem, value: number) => void }) {
  const [values, setValues] = useState<Record<string, string>>({});
  return <div className="table-scroll"><table className="admin-table inventory-table"><thead><tr><th>Piece</th><th>SKU</th><th>Stock</th><th>Level</th><th></th></tr></thead><tbody>{inventory.map(item => <tr key={item.productId}><td><strong>{item.productName}</strong></td><td>{item.sku}</td><td><input aria-label={`${item.productName} stock`} type="number" min="0" value={values[item.productId] ?? item.stock} onChange={e => setValues({ ...values, [item.productId]: e.target.value })} /></td><td><span className={`status-pill ${item.lowStock ? 'pending' : 'paid'}`}>{item.lowStock ? 'Low stock' : 'In stock'}</span></td><td><button className="text-link" disabled={Number(values[item.productId] ?? item.stock) === item.stock} onClick={() => onSave(item, Math.max(0, Number(values[item.productId])))}>Save</button></td></tr>)}</tbody></table></div>;
}
function ProductEditor({ product, onClose, onSave, error, pending }: { product: Product | null; onClose: () => void; onSave: (p: ProductInput) => void; error: string; pending: boolean }) {
  const [form, setForm] = useState<ProductInput>(() => product ? { name: product.name, slug: product.slug, description: product.description, price: product.price, compareAtPrice: product.compareAtPrice ?? undefined, category: product.category, images: product.images, sizes: product.sizes, colors: product.colors, stock: product.stock, sku: product.sku, featured: product.featured, newArrival: product.newArrival, published: product.published } : { name: '', slug: '', description: '', price: 0, category: '', images: [], sizes: [], colors: [], stock: 0, sku: '', featured: false, newArrival: true, published: false });
  const [imageUrl, setImageUrl] = useState(product?.images[0]?.url || '');
  const [sizesInput, setSizesInput] = useState(product?.sizes.join(', ') || '');
  const [colorsInput, setColorsInput] = useState(product?.colors.join(', ') || '');
  const [uploadNote, setUploadNote] = useState('');
  const [uploading, setUploading] = useState(false);
  const change = (key: keyof ProductInput, value: string | number | boolean) => setForm(current => ({ ...current, [key]: value } as ProductInput));
  const uploadImage = async (file?: File) => {
    if (!file) return;
    if (!storageBucket || !authUrl || !authKey) { setUploadNote('Upload unavailable: configure Supabase URL, anon key, and Storage bucket. No file was uploaded.'); return; }
    setUploading(true); setUploadNote('');
    try {
      const session = getSession();
      const safeName = file.name.toLowerCase().replace(/[^a-z0-9.-]+/g, '-');
      const objectPath = `products/${Date.now()}-${safeName}`;
      const response = await fetch(`${authUrl.replace(/\/$/, '')}/storage/v1/object/${encodeURIComponent(storageBucket)}/${objectPath.split('/').map(encodeURIComponent).join('/')}`, {
        method: 'POST',
        headers: { apikey: authKey, Authorization: `Bearer ${session?.access_token || authKey}`, 'Content-Type': file.type || 'application/octet-stream', 'x-upsert': 'true' },
        body: file,
      });
      if (!response.ok) {
        const payload = await response.json().catch(() => ({})) as { message?: string; error?: string };
        throw new Error(payload.message || payload.error || 'Storage upload failed. Check bucket access and try again.');
      }
      setImageUrl(`${authUrl.replace(/\/$/, '')}/storage/v1/object/public/${encodeURIComponent(storageBucket)}/${objectPath.split('/').map(encodeURIComponent).join('/')}`);
      setUploadNote('Image uploaded to the configured Supabase Storage bucket.');
    } catch (err) { setUploadNote(err instanceof Error ? err.message : 'Upload failed. No image URL was changed.'); }
    finally { setUploading(false); }
  };
  const submit = (e: FormEvent) => { e.preventDefault(); onSave({ ...form, slug: form.slug || form.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''), images: imageUrl ? [{ url: imageUrl, alt: form.name }] : [], sizes: sizesInput.split(',').map(s => s.trim()).filter(Boolean), colors: colorsInput.split(',').map(s => s.trim()).filter(Boolean), price: Number(form.price), stock: Number(form.stock), compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : undefined }); };
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><form className="product-modal" onSubmit={submit}><div className="modal-heading"><div><span className="eyebrow">{product ? 'EDIT THE DETAILS' : 'A NEW ADDITION'}</span><h2>{product ? 'Refine this piece.' : 'Add to the collection.'}</h2></div><button type="button" className="icon-button" aria-label="Close" onClick={onClose}><X size={19} /></button></div><div className="editor-grid"><label className="field">Product name<input required minLength={2} value={form.name} onChange={e => change('name', e.target.value)} /></label><label className="field">Slug<input value={form.slug} onChange={e => change('slug', e.target.value)} placeholder="generated-from-name" /></label><label className="field">Category<input required value={form.category} onChange={e => change('category', e.target.value)} /></label><label className="field">SKU<input required value={form.sku} onChange={e => change('sku', e.target.value)} /></label><label className="field">Price (₹)<input required type="number" min="0" value={form.price} onChange={e => change('price', Number(e.target.value))} /></label><label className="field">Compare-at price<input type="number" min="0" value={form.compareAtPrice ?? ''} onChange={e => change('compareAtPrice', Number(e.target.value))} /></label><label className="field">Stock<input required type="number" min="0" value={form.stock} onChange={e => change('stock', Number(e.target.value))} /></label><label className="field">Sizes, comma separated<input value={sizesInput} onChange={e => setSizesInput(e.target.value)} placeholder="S, M, L, XL" /></label><label className="field full-field">Colors, comma separated<input value={colorsInput} onChange={e => setColorsInput(e.target.value)} placeholder="Black, Stone" /></label><label className="field full-field">Description<textarea rows={3} value={form.description} onChange={e => change('description', e.target.value)} /></label><label className="field full-field">Product image URL<input type="url" value={imageUrl} onChange={e => { setImageUrl(e.target.value); setUploadNote(''); }} placeholder="https://…" /></label></div><div className="upload-state">{storageBucket ? <>Storage bucket configured: <strong>{storageBucket}</strong>. Select an image file to upload or add a public image URL above.<label className="upload-file">Choose image<input type="file" accept="image/*" disabled={uploading} onChange={e => uploadImage(e.target.files?.[0])} /></label></> : <>Image upload is not configured. Set <code>VITE_SUPABASE_STORAGE_BUCKET</code> to enable Storage. You can add a public image URL above.</>}{uploadNote && <span>{uploadNote}</span>}{uploading && <span>Uploading image…</span>}</div><div className="editor-toggles"><label><input type="checkbox" checked={form.featured} onChange={e => change('featured', e.target.checked)} /> Featured</label><label><input type="checkbox" checked={form.newArrival} onChange={e => change('newArrival', e.target.checked)} /> New arrival</label><label><input type="checkbox" checked={form.published} onChange={e => change('published', e.target.checked)} /> Published</label></div>{error && <div className="inline-error"><CircleAlert size={16} />{error}</div>}<div className="modal-actions"><button type="button" className="text-link" onClick={onClose}>Cancel</button><button className="button button-dark compact" disabled={pending || uploading}>{pending ? 'Saving…' : product ? 'Save changes' : 'Create piece'}</button></div></form></div>;
}
function App() {
  const cart = useCart();
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Switch>
    <Route path="/"><Shell cart={cart}><HomePage /></Shell></Route>
    <Route path="/shop"><Shell cart={cart}><ShopPage /></Shell></Route>
    <Route path="/products/:slug"><Shell cart={cart}><ProductPageView cart={cart} /></Shell></Route>
    <Route path="/cart"><Shell cart={cart}><CartPage cart={cart} /></Shell></Route>
    <Route path="/checkout"><Shell cart={cart}><CheckoutPage cart={cart} /></Shell></Route>
    <Route path="/orders/confirmed"><Shell cart={cart}><ConfirmationPage /></Shell></Route>
    <Route path="/account"><Shell cart={cart}><AccountPage /></Shell></Route>
    <Route path="/admin"><AdminPage /></Route>
    <Route><Shell cart={cart}><NotFoundPage /></Shell></Route>
  </Switch></WouterRouter></QueryClientProvider>;
}
function NotFoundPage() { return <main className="not-found"><span className="eyebrow">404 / NOT FOUND</span><h1>That piece<br /><em>isn't here.</em></h1><p>It may have moved on. Let's find you something else.</p><Link href="/shop" className="button button-dark">Shop the collection <ArrowRight size={16} /></Link></main>; }
export default App;