import type { Request, Response } from "express";
import { eq } from "drizzle-orm";
import { db, profilesTable } from "@workspace/db";

export type StoreUser = {
  id: string;
  email: string;
  fullName: string;
  isAdmin: boolean;
};

type SupabaseUserResponse = {
  id?: unknown;
  email?: unknown;
  user_metadata?: Record<string, unknown>;
};

function getBearerToken(req: Request): string | undefined {
  const header = req.get("authorization");
  if (!header?.startsWith("Bearer ")) return undefined;
  return header.slice("Bearer ".length).trim() || undefined;
}

export async function getOptionalStoreUser(
  req: Request,
  res: Response,
): Promise<StoreUser | null> {
  const token = getBearerToken(req);
  if (!token) return null;

  const supabaseUrl = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!supabaseUrl || !anonKey) {
    res.status(503).json({ error: "Customer account services are not configured." });
    return null;
  }

  try {
    const response = await fetch(`${supabaseUrl.replace(/\/$/, "")}/auth/v1/user`, {
      headers: {
        apikey: anonKey,
        authorization: `Bearer ${token}`,
      },
    });
    if (!response.ok) {
      res.status(401).json({ error: "Your session is invalid or has expired." });
      return null;
    }

    const payload = (await response.json()) as SupabaseUserResponse;
    if (typeof payload.id !== "string" || typeof payload.email !== "string") {
      res.status(401).json({ error: "Your session is invalid or has expired." });
      return null;
    }

    const fullName =
      typeof payload.user_metadata?.full_name === "string"
        ? payload.user_metadata.full_name
        : typeof payload.user_metadata?.name === "string"
          ? payload.user_metadata.name
          : "";

    await db
      .insert(profilesTable)
      .values({ id: payload.id, email: payload.email, fullName })
      .onConflictDoUpdate({
        target: profilesTable.id,
        set: { email: payload.email, fullName },
      });

    const [profile] = await db
      .select({ isAdmin: profilesTable.isAdmin })
      .from(profilesTable)
      .where(eq(profilesTable.id, payload.id))
      .limit(1);

    return {
      id: payload.id,
      email: payload.email,
      fullName,
      isAdmin: profile?.isAdmin ?? false,
    };
  } catch {
    res.status(503).json({ error: "Customer account services are temporarily unavailable." });
    return null;
  }
}

export async function requireStoreUser(
  req: Request,
  res: Response,
  adminOnly = false,
): Promise<StoreUser | null> {
  if (!getBearerToken(req)) {
    res.status(401).json({ error: "Sign in to continue." });
    return null;
  }
  const user = await getOptionalStoreUser(req, res);
  if (!user) return null;
  if (adminOnly && !user.isAdmin) {
    res.status(403).json({ error: "Store administrator access is required." });
    return null;
  }
  return user;
}
