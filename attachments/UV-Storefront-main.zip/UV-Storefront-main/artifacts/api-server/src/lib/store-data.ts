import { asc, inArray } from "drizzle-orm";
import { db, orderItemsTable, productImagesTable } from "@workspace/db";
import type { Order, Product, ShippingAddress } from "@workspace/db";

export type ProductJoinRow = {
  product: Product;
  categoryName: string;
  stock: number;
  reserved: number;
};

export async function hydrateProducts(rows: ProductJoinRow[]) {
  if (rows.length === 0) return [];
  const ids = rows.map(({ product }) => product.id);
  const imageRows = await db
    .select()
    .from(productImagesTable)
    .where(inArray(productImagesTable.productId, ids))
    .orderBy(asc(productImagesTable.position));
  const imagesByProduct = new Map<
    string,
    { url: string; alt: string }[]
  >();
  for (const image of imageRows) {
    const list = imagesByProduct.get(image.productId) ?? [];
    list.push({ url: image.url, alt: image.alt });
    imagesByProduct.set(image.productId, list);
  }

  return rows.map(({ product, categoryName, stock, reserved }) => ({
    id: product.id,
    name: product.name,
    slug: product.slug,
    description: product.description,
    price: Number(product.price),
    compareAtPrice:
      product.compareAtPrice === null ? null : Number(product.compareAtPrice),
    category: categoryName,
    images: imagesByProduct.get(product.id) ?? [],
    sizes: product.sizes,
    colors: product.colors,
    stock: Math.max(0, stock - reserved),
    sku: product.sku,
    featured: product.featured,
    newArrival: product.newArrival,
    published: product.published,
    createdAt: product.createdAt.toISOString(),
  }));
}

export async function hydrateOrders(orders: Order[]) {
  if (orders.length === 0) return [];
  const items = await db
    .select()
    .from(orderItemsTable)
    .where(
      inArray(
        orderItemsTable.orderId,
        orders.map((order) => order.id),
      ),
    )
    .orderBy(asc(orderItemsTable.id));
  const itemsByOrder = new Map<string, typeof items>();
  for (const item of items) {
    const list = itemsByOrder.get(item.orderId) ?? [];
    list.push(item);
    itemsByOrder.set(item.orderId, list);
  }

  return orders.map((order) => ({
    id: order.id,
    orderNumber: order.orderNumber,
    customerName: order.customerName,
    customerEmail: order.customerEmail,
    items: (itemsByOrder.get(order.id) ?? []).map((item) => ({
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: Number(item.unitPrice),
      size: item.size,
      color: item.color,
      image: item.imageUrl,
    })),
    subtotal: Number(order.subtotal),
    shipping: Number(order.shipping),
    total: Number(order.total),
    paymentStatus: order.paymentStatus,
    status: order.status,
    shippingAddress: order.shippingAddress as ShippingAddress,
    createdAt: order.createdAt.toISOString(),
  }));
}
