import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { Buffer } from "node:buffer";
import {
  and,
  arrayContains,
  asc,
  count,
  desc,
  eq,
  gte,
  ilike,
  inArray,
  lte,
  or,
  sql,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  addressesTable,
  categoriesTable,
  db,
  inventoryTable,
  orderItemsTable,
  ordersTable,
  productImagesTable,
  productsTable,
} from "@workspace/db";
import {
  CreateCheckoutOrderBody,
  CreateCheckoutOrderResponse,
  GetProductParams,
  GetProductResponse,
  ListAccountOrdersResponse,
  ListCollectionsResponse,
  ListProductsQueryParams,
  ListProductsResponse,
  VerifyCheckoutPaymentBody,
  VerifyCheckoutPaymentParams,
  VerifyCheckoutPaymentResponse,
} from "@workspace/api-zod";
import { hydrateOrders, hydrateProducts, type ProductJoinRow } from "../lib/store-data";
import { getOptionalStoreUser, requireStoreUser } from "../lib/store-auth";

const router: IRouter = Router();
const FREE_SHIPPING_THRESHOLD = 2500;
const STANDARD_SHIPPING = 99;
const RESERVATION_MINUTES = 30;

function parseResponse<T>(schema: { parse: (value: unknown) => T }, value: unknown): T {
  return schema.parse(value);
}

function getRazorpayCredentials():
  | { keyId: string; keySecret: string }
  | undefined {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  return keyId && keySecret ? { keyId, keySecret } : undefined;
}

async function createRazorpayOrder(
  keyId: string,
  keySecret: string,
  appOrderId: string,
  orderNumber: string,
  amount: number,
): Promise<string> {
  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      amount,
      currency: "INR",
      receipt: orderNumber,
      notes: { uv_order_id: appOrderId },
    }),
  });
  const payload = (await response.json()) as { id?: unknown; error?: unknown };
  if (!response.ok || typeof payload.id !== "string") {
    throw new Error("Payment provider could not create an order.");
  }
  return payload.id;
}

async function releaseExpiredReservations(): Promise<void> {
  const now = new Date();
  await db.transaction(async (tx) => {
    const expired = await tx
      .select({ id: ordersTable.id })
      .from(ordersTable)
      .where(
        and(
          eq(ordersTable.status, "pending"),
          eq(ordersTable.paymentStatus, "pending"),
          lte(ordersTable.expiresAt, now),
        ),
      )
      .for("update");

    for (const order of expired) {
      const [cancelled] = await tx
        .update(ordersTable)
        .set({
          status: "cancelled",
          paymentStatus: "failed",
          updatedAt: now,
        })
        .where(
          and(
            eq(ordersTable.id, order.id),
            eq(ordersTable.status, "pending"),
            eq(ordersTable.paymentStatus, "pending"),
          ),
        )
        .returning({ id: ordersTable.id });
      if (!cancelled) continue;

      const lines = await tx
        .select({
          productId: orderItemsTable.productId,
          quantity: orderItemsTable.quantity,
        })
        .from(orderItemsTable)
        .where(eq(orderItemsTable.orderId, order.id));
      const reservedByProduct = new Map<string, number>();
      for (const line of lines) {
        if (line.productId) {
          reservedByProduct.set(
            line.productId,
            (reservedByProduct.get(line.productId) ?? 0) + line.quantity,
          );
        }
      }
      for (const [productId, quantity] of reservedByProduct) {
        await tx
          .update(inventoryTable)
          .set({
            reserved: sql`greatest(${inventoryTable.reserved} - ${quantity}, 0)`,
            updatedAt: now,
          })
          .where(eq(inventoryTable.productId, productId));
      }
    }
  });
}

router.get("/products", async (req, res): Promise<void> => {
  const parsed = ListProductsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const query = parsed.data;
  const page = query.page ?? 1;
  const pageSize = query.pageSize ?? 12;
  const filters = [
    eq(productsTable.published, true),
    ...(query.category
      ? [eq(categoriesTable.slug, query.category)]
      : []),
    ...(query.size
      ? [arrayContains(productsTable.sizes, [query.size])]
      : []),
    ...(query.color
      ? [arrayContains(productsTable.colors, [query.color])]
      : []),
    ...(query.minPrice !== undefined
      ? [gte(productsTable.price, String(query.minPrice))]
      : []),
    ...(query.maxPrice !== undefined
      ? [lte(productsTable.price, String(query.maxPrice))]
      : []),
    ...(query.search
      ? [
          or(
            ilike(productsTable.name, `%${query.search}%`),
            ilike(productsTable.sku, `%${query.search}%`),
            ilike(categoriesTable.name, `%${query.search}%`),
          )!,
        ]
      : []),
  ];
  const where = and(...filters);
  const ordering =
    query.sort === "price-asc"
      ? [asc(productsTable.price)]
      : query.sort === "price-desc"
        ? [desc(productsTable.price)]
        : query.sort === "newest"
          ? [desc(productsTable.createdAt)]
          : [desc(productsTable.featured), desc(productsTable.createdAt)];

  const [rows, totalRows] = await Promise.all([
    db
      .select({
        product: productsTable,
        categoryName: categoriesTable.name,
        stock: inventoryTable.stock,
        reserved: inventoryTable.reserved,
      })
      .from(productsTable)
      .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
      .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
      .where(where)
      .orderBy(...ordering)
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db
      .select({ value: count() })
      .from(productsTable)
      .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
      .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
      .where(where),
  ]);
  const items = await hydrateProducts(rows as ProductJoinRow[]);
  res.json(
    parseResponse(ListProductsResponse, {
      items,
      total: totalRows[0]?.value ?? 0,
      page,
      pageSize,
    }),
  );
});

router.get("/products/:slug", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
    .where(
      and(
        eq(productsTable.slug, params.data.slug),
        eq(productsTable.published, true),
      ),
    )
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Product not found." });
    return;
  }
  const [product] = await hydrateProducts([row as ProductJoinRow]);
  res.json(parseResponse(GetProductResponse, product));
});

router.get("/collections", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      name: categoriesTable.name,
      slug: categoriesTable.slug,
      productCount: count(productsTable.id),
    })
    .from(categoriesTable)
    .innerJoin(productsTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.published, true))
    .groupBy(categoriesTable.id, categoriesTable.name, categoriesTable.slug)
    .orderBy(asc(categoriesTable.name));
  res.json(
    parseResponse(
      ListCollectionsResponse,
      rows.map((row) => ({ ...row, image: null })),
    ),
  );
});

router.post("/checkout/orders", async (req, res): Promise<void> => {
  const parsed = CreateCheckoutOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const credentials = getRazorpayCredentials();
  if (!credentials) {
    res.status(503).json({
      error:
        "Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to the server environment.",
    });
    return;
  }

  const user = await getOptionalStoreUser(req, res);
  if (res.headersSent) return;
  await releaseExpiredReservations();
  const { items, shippingAddress } = parsed.data;
  const productIds = [...new Set(items.map((item) => item.productId))];
  const rows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
    .where(
      and(
        inArray(productsTable.id, productIds),
        eq(productsTable.published, true),
      ),
    );
  if (rows.length !== productIds.length) {
    res.status(400).json({ error: "One or more products are no longer available." });
    return;
  }
  const productById = new Map(rows.map((row) => [row.product.id, row]));
  const quantityByProduct = new Map<string, number>();
  type OrderItemInput = Omit<typeof orderItemsTable.$inferInsert, "orderId">;
  const orderItemValues: OrderItemInput[] = [];
  let subtotal = 0;

  for (const item of items) {
    const row = productById.get(item.productId);
    if (!row) {
      res.status(400).json({ error: "One or more products are no longer available." });
      return;
    }
    if (
      !row.product.sizes.includes(item.size) ||
      !row.product.colors.includes(item.color)
    ) {
      res.status(400).json({ error: "A selected size or color is unavailable." });
      return;
    }
    const quantity = (quantityByProduct.get(item.productId) ?? 0) + item.quantity;
    quantityByProduct.set(item.productId, quantity);
    if (quantity > row.stock - row.reserved) {
      res.status(409).json({ error: `${row.product.name} does not have enough stock.` });
      return;
    }
    const unitPrice = Number(row.product.price);
    subtotal += unitPrice * item.quantity;
    orderItemValues.push({
      productId: row.product.id,
      productName: row.product.name,
      sku: row.product.sku,
      imageUrl: null as string | null,
      quantity: item.quantity,
      unitPrice: row.product.price,
      size: item.size,
      color: item.color,
    });
  }

  const imageRows = await db
    .select({ productId: productImagesTable.productId, url: productImagesTable.url })
    .from(productImagesTable)
    .where(inArray(productImagesTable.productId, productIds))
    .orderBy(asc(productImagesTable.position));
  const firstImageByProduct = new Map<string, string>();
  for (const image of imageRows) {
    if (!firstImageByProduct.has(image.productId)) {
      firstImageByProduct.set(image.productId, image.url);
    }
  }
  for (const item of orderItemValues) {
    if (item.productId) item.imageUrl = firstImageByProduct.get(item.productId) ?? null;
  }

  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING;
  const total = subtotal + shipping;
  const amount = Math.round(total * 100);
  const appOrderId = randomUUID();
  const orderNumber = `UV-${Date.now().toString().slice(-8)}-${randomUUID()
    .slice(0, 4)
    .toUpperCase()}`;

  let razorpayOrderId: string;
  try {
    razorpayOrderId = await createRazorpayOrder(
      credentials.keyId,
      credentials.keySecret,
      appOrderId,
      orderNumber,
      amount,
    );
  } catch (error) {
    req.log.error({ err: error }, "Unable to create Razorpay order");
    res.status(502).json({ error: "Payment could not be initialized. Please try again." });
    return;
  }

  const expiresAt = new Date(Date.now() + RESERVATION_MINUTES * 60_000);
  try {
    await db.transaction(async (tx) => {
      await tx.insert(ordersTable).values({
        id: appOrderId,
        orderNumber,
        customerId: user?.id ?? null,
        customerName: shippingAddress.fullName,
        customerEmail: shippingAddress.email,
        customerPhone: shippingAddress.phone,
        shippingAddress,
        subtotal: subtotal.toFixed(2),
        shipping: shipping.toFixed(2),
        total: total.toFixed(2),
        status: "pending",
        paymentStatus: "pending",
        razorpayOrderId,
        expiresAt,
      });
      for (const [productId, quantity] of quantityByProduct) {
        const [reserved] = await tx
          .update(inventoryTable)
          .set({
            reserved: sql`${inventoryTable.reserved} + ${quantity}`,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(inventoryTable.productId, productId),
              sql`${inventoryTable.stock} - ${inventoryTable.reserved} >= ${quantity}`,
            ),
          )
          .returning({ productId: inventoryTable.productId });
        if (!reserved) {
          throw new Error("OUT_OF_STOCK");
        }
      }
      await tx.insert(orderItemsTable).values(
        orderItemValues.map((item) => ({ ...item, orderId: appOrderId })),
      );
      if (user) {
        await tx.insert(addressesTable).values({
          customerId: user.id,
          fullName: shippingAddress.fullName,
          email: shippingAddress.email,
          phone: shippingAddress.phone,
          address: shippingAddress.address,
          city: shippingAddress.city,
          state: shippingAddress.state,
          pincode: shippingAddress.pincode,
        });
      }
    });
  } catch (error) {
    if (error instanceof Error && error.message === "OUT_OF_STOCK") {
      res.status(409).json({ error: "Stock changed while you were checking out. Please review your cart." });
      return;
    }
    req.log.error({ err: error, orderId: appOrderId }, "Unable to save checkout order");
    res.status(500).json({ error: "The order could not be saved. Please try again." });
    return;
  }

  res.status(201).json(
    parseResponse(CreateCheckoutOrderResponse, {
      orderId: appOrderId,
      orderNumber,
      razorpayOrderId,
      amount,
      currency: "INR",
      keyId: credentials.keyId,
    }),
  );
});

router.post("/checkout/orders/:orderId/verify", async (req, res): Promise<void> => {
  const params = VerifyCheckoutPaymentParams.safeParse(req.params);
  const parsed = VerifyCheckoutPaymentBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.success
        ? parsed.error?.message ?? "Invalid payment verification data."
        : params.error.message,
    });
    return;
  }
  const credentials = getRazorpayCredentials();
  if (!credentials) {
    res.status(503).json({ error: "Razorpay payment verification is not configured." });
    return;
  }
  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, params.data.orderId))
    .limit(1);
  if (!order || order.razorpayOrderId !== parsed.data.razorpayOrderId) {
    res.status(404).json({ error: "Order not found." });
    return;
  }

  const expectedSignature = createHmac("sha256", credentials.keySecret)
    .update(`${parsed.data.razorpayOrderId}|${parsed.data.razorpayPaymentId}`)
    .digest();
  let suppliedSignature: Buffer;
  try {
    suppliedSignature = Buffer.from(parsed.data.razorpaySignature, "hex");
  } catch {
    res.status(400).json({ error: "Payment signature is invalid." });
    return;
  }
  if (
    suppliedSignature.length !== expectedSignature.length ||
    !timingSafeEqual(suppliedSignature, expectedSignature)
  ) {
    res.status(400).json({ error: "Payment signature is invalid." });
    return;
  }

  if (order.paymentStatus === "paid") {
    if (order.razorpayPaymentId !== parsed.data.razorpayPaymentId) {
      res.status(409).json({ error: "This order has already been paid with a different payment." });
      return;
    }
    const [confirmed] = await hydrateOrders([order]);
    res.json(
      parseResponse(VerifyCheckoutPaymentResponse, {
        order: confirmed,
        paymentStatus: "paid",
      }),
    );
    return;
  }
  if (order.status === "cancelled") {
    res.status(409).json({ error: "This checkout session expired. Contact the store for payment assistance." });
    return;
  }

  try {
    await db.transaction(async (tx) => {
      const [lockedOrder] = await tx
        .select()
        .from(ordersTable)
        .where(eq(ordersTable.id, order.id))
        .for("update");
      if (!lockedOrder || lockedOrder.paymentStatus !== "pending") {
        throw new Error("ORDER_ALREADY_PROCESSED");
      }
      const lines = await tx
        .select({
          productId: orderItemsTable.productId,
          quantity: orderItemsTable.quantity,
        })
        .from(orderItemsTable)
        .where(eq(orderItemsTable.orderId, order.id));
      const quantityByProduct = new Map<string, number>();
      for (const line of lines) {
        if (line.productId) {
          quantityByProduct.set(
            line.productId,
            (quantityByProduct.get(line.productId) ?? 0) + line.quantity,
          );
        }
      }
      for (const [productId, quantity] of quantityByProduct) {
        const [updated] = await tx
          .update(inventoryTable)
          .set({
            stock: sql`${inventoryTable.stock} - ${quantity}`,
            reserved: sql`greatest(${inventoryTable.reserved} - ${quantity}, 0)`,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(inventoryTable.productId, productId),
              gte(inventoryTable.stock, quantity),
            ),
          )
          .returning({ productId: inventoryTable.productId });
        if (!updated) throw new Error("STOCK_RESERVATION_MISSING");
      }
      const [savedOrder] = await tx
        .update(ordersTable)
        .set({
          paymentStatus: "paid",
          status: "paid",
          razorpayPaymentId: parsed.data.razorpayPaymentId,
          updatedAt: new Date(),
        })
        .where(eq(ordersTable.id, order.id))
        .returning({ id: ordersTable.id });
      if (!savedOrder) throw new Error("ORDER_NOT_FOUND");
    });
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === "ORDER_ALREADY_PROCESSED" ||
        error.message === "STOCK_RESERVATION_MISSING")
    ) {
      res.status(409).json({
        error: "Payment was received but the order needs store support. Please contact UV with your order number.",
      });
      return;
    }
    req.log.error({ err: error, orderId: order.id }, "Unable to finalize verified payment");
    res.status(500).json({
      error: "Payment was verified but the order could not be finalized. Contact the store with your order number.",
    });
    return;
  }

  const [paidOrder] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, order.id))
    .limit(1);
  const [confirmed] = await hydrateOrders(paidOrder ? [paidOrder] : []);
  if (!confirmed) {
    res.status(500).json({ error: "Payment was verified but order details could not be loaded." });
    return;
  }
  res.json(
    parseResponse(VerifyCheckoutPaymentResponse, {
      order: confirmed,
      paymentStatus: "paid",
    }),
  );
});

router.get("/account/orders", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res);
  if (!user) return;
  const orders = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.customerId, user.id))
    .orderBy(desc(ordersTable.createdAt));
  res.json(parseResponse(ListAccountOrdersResponse, await hydrateOrders(orders)));
});

export default router;