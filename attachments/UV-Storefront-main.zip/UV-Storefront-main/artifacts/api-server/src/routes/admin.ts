import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  inArray,
  sql,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  categoriesTable,
  db,
  inventoryTable,
  orderItemsTable,
  ordersTable,
  productImagesTable,
  productsTable,
} from "@workspace/db";
import {
  CreateProductBody,
  CreateProductResponse,
  DeleteProductParams,
  GetAdminDashboardResponse,
  ListAdminOrdersQueryParams,
  ListAdminOrdersResponse,
  ListAdminProductsResponse,
  ListInventoryResponse,
  UpdateInventoryBody,
  UpdateInventoryParams,
  UpdateInventoryResponse,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
  UpdateOrderStatusResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
} from "@workspace/api-zod";
import { hydrateOrders, hydrateProducts, type ProductJoinRow } from "../lib/store-data";
import { requireStoreUser } from "../lib/store-auth";

const router: IRouter = Router();

function slugify(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

async function getProductView(productId: string) {
  const [row] = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
    .where(eq(productsTable.id, productId))
    .limit(1);
  if (!row) return null;
  const [product] = await hydrateProducts([row as ProductJoinRow]);
  return product;
}

async function saveProduct(
  productId: string | undefined,
  input: typeof CreateProductBody._type,
): Promise<string> {
  const slug = slugify(input.slug);
  if (!slug) throw new Error("INVALID_SLUG");
  const categorySlug = slugify(input.category);
  if (!categorySlug) throw new Error("INVALID_CATEGORY");

  return db.transaction(async (tx) => {
    const [category] = await tx
      .insert(categoriesTable)
      .values({
        name: input.category.trim(),
        slug: categorySlug,
      })
      .onConflictDoUpdate({
        target: categoriesTable.slug,
        set: { name: input.category.trim() },
      })
      .returning({ id: categoriesTable.id });

    if (!category) throw new Error("CATEGORY_NOT_SAVED");

    const values = {
      categoryId: category.id,
      name: input.name.trim(),
      slug,
      description: input.description,
      price: String(input.price),
      compareAtPrice:
        input.compareAtPrice === null || input.compareAtPrice === undefined
          ? null
          : String(input.compareAtPrice),
      sku: input.sku.trim(),
      sizes: input.sizes,
      colors: input.colors,
      featured: input.featured,
      newArrival: input.newArrival,
      published: input.published,
    };

    let savedId = productId;
    if (productId) {
      const [updated] = await tx
        .update(productsTable)
        .set(values)
        .where(eq(productsTable.id, productId))
        .returning({ id: productsTable.id });
      if (!updated) throw new Error("PRODUCT_NOT_FOUND");
      savedId = updated.id;
      const [stockUpdated] = await tx
        .update(inventoryTable)
        .set({
          stock: sql`${input.stock} + ${inventoryTable.reserved}`,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(inventoryTable.productId, updated.id),
          ),
        )
        .returning({ productId: inventoryTable.productId });
      if (!stockUpdated) throw new Error("STOCK_RESERVED");
      await tx
        .delete(productImagesTable)
        .where(eq(productImagesTable.productId, updated.id));
    } else {
      const [created] = await tx
        .insert(productsTable)
        .values(values)
        .returning({ id: productsTable.id });
      if (!created) throw new Error("PRODUCT_NOT_CREATED");
      savedId = created.id;
      await tx.insert(inventoryTable).values({
        productId: created.id,
        stock: input.stock,
      });
    }

    if (input.images.length > 0) {
      await tx.insert(productImagesTable).values(
        input.images.map((image, position) => ({
          productId: savedId!,
          url: image.url,
          alt: image.alt,
          position,
        })),
      );
    }
    return savedId!;
  });
}

router.get("/admin/dashboard", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const [[ordersCount], [revenue], [productsCount], lowStockRows, recentRows] =
    await Promise.all([
      db.select({ value: count() }).from(ordersTable),
      db
        .select({ value: sql<string>`coalesce(sum(${ordersTable.total}), 0)` })
        .from(ordersTable)
        .where(eq(ordersTable.paymentStatus, "paid")),
      db.select({ value: count() }).from(productsTable),
      db
        .select({
          stock: inventoryTable.stock,
          reserved: inventoryTable.reserved,
          threshold: inventoryTable.lowStockThreshold,
        })
        .from(inventoryTable),
      db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(5),
    ]);
  const lowStockCount = lowStockRows.filter(
    (item) => item.stock - item.reserved <= item.threshold,
  ).length;
  const recentOrders = await hydrateOrders(recentRows);
  res.json(
    GetAdminDashboardResponse.parse({
      totalOrders: ordersCount?.value ?? 0,
      totalRevenue: Number(revenue?.value ?? 0),
      productCount: productsCount?.value ?? 0,
      lowStockCount,
      recentOrders,
    }),
  );
});

router.get("/admin/products", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const rows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
    })
    .from(productsTable)
    .innerJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .innerJoin(inventoryTable, eq(productsTable.id, inventoryTable.productId))
    .orderBy(desc(productsTable.createdAt));
  res.json(
    ListAdminProductsResponse.parse(
      await hydrateProducts(rows as ProductJoinRow[]),
    ),
  );
});

router.post("/admin/products", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const productId = await saveProduct(undefined, parsed.data);
    const product = await getProductView(productId);
    if (!product) {
      res.status(500).json({ error: "The product was created but could not be loaded." });
      return;
    }
    res.status(201).json(CreateProductResponse.parse(product));
  } catch (error) {
    if (error instanceof Error && error.message === "INVALID_SLUG") {
      res.status(400).json({ error: "Enter a valid product URL slug." });
      return;
    }
    if (error instanceof Error && error.message === "INVALID_CATEGORY") {
      res.status(400).json({ error: "Enter a valid product category." });
      return;
    }
    req.log.error({ err: error }, "Unable to create product");
    res.status(409).json({ error: "A product with this slug or SKU already exists." });
  }
});

router.patch("/admin/products/:productId", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const params = UpdateProductParams.safeParse(req.params);
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.success
        ? parsed.error?.message ?? "Invalid product data."
        : params.error.message,
    });
    return;
  }
  try {
    await saveProduct(params.data.productId, parsed.data);
    const product = await getProductView(params.data.productId);
    if (!product) {
      res.status(404).json({ error: "Product not found." });
      return;
    }
    res.json(UpdateProductResponse.parse(product));
  } catch (error) {
    if (error instanceof Error && error.message === "PRODUCT_NOT_FOUND") {
      res.status(404).json({ error: "Product not found." });
      return;
    }
    if (error instanceof Error && error.message === "STOCK_RESERVED") {
      res.status(409).json({ error: "Stock cannot be lower than the quantity reserved for pending checkouts." });
      return;
    }
    req.log.error({ err: error, productId: params.data.productId }, "Unable to update product");
    res.status(409).json({ error: "Product details conflict with an existing slug or SKU." });
  }
});

router.delete("/admin/products/:productId", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const pendingRows = await db
    .select({ id: orderItemsTable.id })
    .from(orderItemsTable)
    .innerJoin(ordersTable, eq(orderItemsTable.orderId, ordersTable.id))
    .where(
      and(
        eq(orderItemsTable.productId, params.data.productId),
        eq(ordersTable.status, "pending"),
      ),
    )
    .limit(1);
  if (pendingRows.length > 0) {
    res.status(409).json({
      error: "This product has an active checkout. Hide it until that checkout expires.",
    });
    return;
  }
  const [deleted] = await db
    .delete(productsTable)
    .where(eq(productsTable.id, params.data.productId))
    .returning({ id: productsTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Product not found." });
    return;
  }
  res.sendStatus(204);
});

router.get("/admin/inventory", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const rows = await db
    .select({
      productId: productsTable.id,
      productName: productsTable.name,
      sku: productsTable.sku,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
      threshold: inventoryTable.lowStockThreshold,
    })
    .from(inventoryTable)
    .innerJoin(productsTable, eq(inventoryTable.productId, productsTable.id))
    .orderBy(asc(productsTable.name));
  res.json(
    ListInventoryResponse.parse(
      rows.map((row) => ({
        productId: row.productId,
        productName: row.productName,
        sku: row.sku,
        stock: Math.max(0, row.stock - row.reserved),
        lowStock: row.stock - row.reserved <= row.threshold,
      })),
    ),
  );
});

router.patch("/admin/inventory/:productId", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const params = UpdateInventoryParams.safeParse(req.params);
  const parsed = UpdateInventoryBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.success
        ? parsed.error?.message ?? "Invalid inventory data."
        : params.error.message,
    });
    return;
  }
  const [updated] = await db
    .update(inventoryTable)
    .set({
      stock: sql`${parsed.data.stock} + ${inventoryTable.reserved}`,
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(inventoryTable.productId, params.data.productId),
      ),
    )
    .returning({
      productId: inventoryTable.productId,
      stock: inventoryTable.stock,
      reserved: inventoryTable.reserved,
      threshold: inventoryTable.lowStockThreshold,
    });
  if (!updated) {
    const [exists] = await db
      .select({ id: inventoryTable.productId })
      .from(inventoryTable)
      .where(eq(inventoryTable.productId, params.data.productId))
      .limit(1);
    res.status(exists ? 409 : 404).json({
      error: exists
        ? "Stock cannot be lower than quantities reserved for checkout."
        : "Inventory record not found.",
    });
    return;
  }
  const [product] = await db
    .select({ productName: productsTable.name, sku: productsTable.sku })
    .from(productsTable)
    .where(eq(productsTable.id, updated.productId))
    .limit(1);
  res.json(
    UpdateInventoryResponse.parse({
      productId: updated.productId,
      productName: product?.productName ?? "",
      sku: product?.sku ?? "",
      stock: Math.max(0, updated.stock - updated.reserved),
      lowStock: updated.stock - updated.reserved <= updated.threshold,
    }),
  );
});

router.get("/admin/orders", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const parsed = ListAdminOrdersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const orders = await db
    .select()
    .from(ordersTable)
    .where(
      parsed.data.status
        ? eq(ordersTable.status, parsed.data.status)
        : undefined,
    )
    .orderBy(desc(ordersTable.createdAt));
  res.json(ListAdminOrdersResponse.parse(await hydrateOrders(orders)));
});

router.patch("/admin/orders/:orderId/status", async (req, res): Promise<void> => {
  const user = await requireStoreUser(req, res, true);
  if (!user) return;
  const params = UpdateOrderStatusParams.safeParse(req.params);
  const parsed = UpdateOrderStatusBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: params.success
        ? parsed.error?.message ?? "Invalid order status."
        : params.error.message,
    });
    return;
  }
  const [order] = await db
    .update(ordersTable)
    .set({ status: parsed.data.status, updatedAt: new Date() })
    .where(eq(ordersTable.id, params.data.orderId))
    .returning();
  if (!order) {
    res.status(404).json({ error: "Order not found." });
    return;
  }
  const [view] = await hydrateOrders([order]);
  res.json(UpdateOrderStatusResponse.parse(view));
});

export default router;